package com.example.wordsgame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class medium extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medium);
    }
}